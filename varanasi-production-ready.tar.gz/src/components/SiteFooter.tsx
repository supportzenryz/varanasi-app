import Link from "next/link";
import Image from "next/image";
import type { Branch } from "@/lib/branches";
import { openingHours, telHref } from "@/lib/branches";
import { fullNav, pageHref } from "@/lib/nav";
import { brand } from "@/lib/brand";

/** Groups consecutive days that share the same hours: "Mon – Thu  17:00 – 22:30". */
function groupHours(hours: ReturnType<typeof openingHours>) {
  const out: { label: string; value: string }[] = [];
  for (const h of hours) {
    const value = h.closed ? "Closed" : `${h.open} – ${h.close}`;
    const last = out[out.length - 1];
    const short = h.day.slice(0, 3);
    if (last && last.value === value) {
      last.label = `${last.label.split(" – ")[0]} – ${short}`;
    } else {
      out.push({ label: short, value });
    }
  }
  return out;
}

export function SiteFooter({ branch, others }: { branch: Branch; others: Branch[] }) {
  const hours = groupHours(openingHours(branch));
  const nav = fullNav(branch.slug);

  return (
    <footer className="bg-ink text-pale/70">
      <div className="mx-auto max-w-[84rem] px-5 lg:px-10 pt-16 pb-12">
        <div className="grid gap-12 lg:grid-cols-[1.1fr_1fr_1fr_1fr]">
          <div>
            <Image src={brand.logo} alt="Varanasi" width={150} height={104} className="h-16 w-auto" />
            <span className="accent block text-[0.58rem] text-gold mt-3">{branch.city}</span>
            <address className="not-italic text-sm mt-5 leading-relaxed">
              {branch.addressLine}<br />{branch.city}, {branch.postcode}
            </address>
            <a href={telHref(branch.phone)} className="text-sm tnum mt-3 inline-block hover:text-gold">
              {branch.phone}
            </a>
            {branch.bookingEmail && (
              <p className="text-sm mt-3">
                <span className="block text-pale/45 text-xs">For table reservations</span>
                <a href={`mailto:${branch.bookingEmail}`} className="hover:text-gold">{branch.bookingEmail}</a>
              </p>
            )}
          </div>

          <div>
            <h2 className="accent text-[0.58rem] text-gold">Opening hours</h2>
            <ul className="mt-5 text-sm grid gap-1.5">
              {hours.map((h) => (
                <li key={h.label} className="flex justify-between gap-4 max-w-[14rem]">
                  <span>{h.label}</span>
                  <span className="tnum text-pale/60">{h.value}</span>
                </li>
              ))}
            </ul>
            {branch.openingNote && <p className="text-xs text-pale/45 mt-3">{branch.openingNote}</p>}
          </div>

          <div>
            <h2 className="accent text-[0.58rem] text-gold">Visit</h2>
            <ul className="mt-5 text-sm grid gap-2.5">
              {nav.map((l) => (
                <li key={l.href + l.label}>
                  <Link href={l.href} className="hover:text-gold">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2 className="accent text-[0.58rem] text-gold">Our restaurants</h2>
            <ul className="mt-5 text-sm grid gap-2.5">
              <li><Link href="/" className="hover:text-gold">All locations</Link></li>
              {others.map((b) => (
                <li key={b.id}>
                  <Link href={`/${b.slug}`} className={b.id === branch.id ? "text-gold" : "hover:text-gold"}>
                    Varanasi {b.city}
                  </Link>
                </li>
              ))}
            </ul>
            <ul className="mt-7 text-sm grid gap-2.5">
              <li><Link href={pageHref(branch.slug, "privacy")} className="hover:text-gold">Privacy &amp; GDPR</Link></li>
              <li><Link href={pageHref(branch.slug, "terms")} className="hover:text-gold">Terms &amp; conditions</Link></li>
            </ul>
            <Image src={brand.award} alt={brand.awardAlt} width={120} height={120}
              className="mt-8 w-[92px] h-auto" />
          </div>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto max-w-[84rem] px-5 lg:px-10 py-6 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-pale/40">
            © {new Date().getFullYear()} Varanasi Restaurant. Birmingham and Leicester.
          </p>
          <Link href={pageHref(branch.slug, "book-online")} className="text-xs text-gold hover:text-gold-deep">
            Make a reservation
          </Link>
        </div>
      </div>
    </footer>
  );
}
