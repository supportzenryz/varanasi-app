"use client";
import Image from "next/image";
import { useActionState } from "react";
import { loginAction } from "./actions";

export default function LoginPage() {
  const [state, action, pending] = useActionState(loginAction, undefined);

  return (
    <main className="dash min-h-dvh grid lg:grid-cols-2 bg-pale text-ink">
      <div className="hidden lg:flex flex-col justify-between bg-ink text-pale p-12">
        <div className="flex items-center gap-3">
          <Image src="/brand/favicon.svg" alt="Varanasi" width={32} height={32} />
          <span className="accent text-xs text-gold font-semibold">Varanasi</span>
        </div>
        <div>
          <h1 className="text-4xl leading-tight max-w-[14ch]">The room behind the restaurant.</h1>
          <p className="mt-4 text-pale/70 max-w-[38ch] text-sm leading-relaxed">
            Menus, private rooms, gift vouchers and enquiries for Birmingham and Leicester — in one place.
          </p>
        </div>
        <span className="text-pale/40 text-xs">Staff access only</span>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-12">
        <form action={action} className="w-full max-w-sm">
          <div className="flex lg:hidden items-center gap-2 mb-6">
            <Image src="/brand/favicon.svg" alt="Varanasi" width={28} height={28} />
            <span className="accent text-xs font-semibold">Varanasi</span>
          </div>
          <span className="accent text-xs text-gold-ink">Sign in</span>
          <h2 className="text-3xl mt-3">Welcome back</h2>
          <p className="text-ink-3 text-sm mt-2 mb-8">Use the account your manager set up for you.</p>

          <label className="block text-sm font-medium mb-1.5" htmlFor="email">Email</label>
          <input id="email" name="email" type="email" autoComplete="username" required
            className="w-full rounded-none border border-[--line] bg-white px-3.5 py-2.5 text-sm outline-none focus:border-gold" />

          <label className="block text-sm font-medium mb-1.5 mt-5" htmlFor="password">Password</label>
          <input id="password" name="password" type="password" autoComplete="current-password" required
            className="w-full rounded-none border border-[--line] bg-white px-3.5 py-2.5 text-sm outline-none focus:border-gold" />

          {state?.error && (
            <p role="alert" className="mt-4 text-sm text-brick bg-clay/10 border-l-2 border-brick px-3 py-2">
              {state.error}
            </p>
          )}

          <button type="submit" disabled={pending}
            className="mt-7 w-full bg-ink text-pale py-3 text-sm font-semibold tracking-wide hover:bg-ink-2 disabled:opacity-60">
            {pending ? "Signing in…" : "Sign in"}
          </button>

          <p className="mt-6 text-xs text-ink-3 leading-relaxed">
            Forgotten your password? Ask an owner to reset it from Staff access.
          </p>
        </form>
      </div>
    </main>
  );
}
