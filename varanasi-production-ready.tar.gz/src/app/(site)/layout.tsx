import "../globals.css";
import { analyticsRules } from "@/lib/booking-config";
import { Analytics } from "@/components/Analytics";
import { Footer } from "@/components/Footer";

/**
 * The public site runs on the dark palette — ink ground, gold accents, the way
 * the printed menus and the original site read. `on-dark` is what tells the
 * form controls (which default to a white box) to follow it.
 */
export default function SiteLayout({ children }: { children: React.ReactNode }) {
  const analytics = analyticsRules();
  return (
    <div className="on-dark bg-ink text-pale min-h-dvh flex flex-col">
      <div className="flex-1">
        {children}
      </div>
      <Footer />
      <Analytics
        measurementId={analytics.ga4MeasurementId}
        consentRequired={analytics.consentRequired}
      />
    </div>
  );
}
