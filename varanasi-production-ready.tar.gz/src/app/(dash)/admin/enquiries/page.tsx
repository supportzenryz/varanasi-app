import Link from "next/link";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { branches, enquiries, privateRooms, users } from "@/db/schema";
import { requireAbility, can } from "@/lib/auth";
import { TYPE_LABEL, type EnquiryType } from "@/lib/enquiry";
import { setEnquiryStatus, saveEnquiryNote } from "./actions";

export const metadata = { title: "Enquiries" };

const field = "w-full border border-[--line] bg-white px-3 py-2 text-sm outline-none focus:border-gold";

const STATUS_COLOUR: Record<string, string> = {
  new: "bg-gold/20 text-gold-ink",
  contacted: "bg-leaf/15 text-leaf",
  confirmed: "bg-ink/10 text-ink",
  closed: "bg-ink/5 text-ink-3",
};

export default async function EnquiriesAdmin({
  searchParams,
}: { searchParams: Promise<{ status?: string; type?: string; branch?: string }> }) {
  const session = await requireAbility("viewEnquiries");
  const { status = "open", type, branch: branchParam } = await searchParams;

  const all = db.select().from(branches).all();
  const visible = session.role === "owner" ? all : all.filter((b) => b.id === session.branchId);
  const branchIds = visible.map((b) => b.id);
  const cityOf = new Map(all.map((b) => [b.id, b.city]));

  const where = [
    // franchise enquiries have no branch, so an owner sees those too
    session.role === "owner"
      ? sql`1 = 1`
      : inArray(enquiries.branchId, branchIds.length ? branchIds : [-1]),
    status === "open" ? inArray(enquiries.status, ["new", "contacted"])
      : status === "all" ? sql`1 = 1`
      : eq(enquiries.status, status as "new" | "contacted" | "confirmed" | "closed"),
    branchParam ? eq(enquiries.branchId, all.find((b) => b.slug === branchParam)?.id ?? -1) : sql`1 = 1`,
    type ? eq(enquiries.type, type as EnquiryType) : sql`1 = 1`,
  ];

  const rows = db.select().from(enquiries).where(and(...where))
    .orderBy(desc(enquiries.createdAt)).limit(100).all();

  const counts = db.select({ status: enquiries.status, n: sql<number>`count(*)` })
    .from(enquiries).groupBy(enquiries.status).all();
  const countOf = (s: string) => counts.find((c) => c.status === s)?.n ?? 0;

  const staff = db.select({ id: users.id, name: users.name }).from(users).all();
  const staffName = new Map(staff.map((s) => [s.id, s.name]));
  const rooms = db.select({ id: privateRooms.id, name: privateRooms.name }).from(privateRooms).all();
  const roomName = new Map(rooms.map((r) => [r.id, r.name]));

  const editable = can(session, "editEnquiries");
  const q = (o: Record<string, string | undefined>) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries({ status, type, branch: branchParam, ...o })) if (v) p.set(k, v);
    return `/admin/enquiries?${p.toString()}`;
  };

  return (
    <>
      <span className="accent text-xs text-gold-ink">Enquiries</span>
      <h1 className="text-3xl sm:text-4xl mt-3">Enquiries</h1>
      <p className="text-ink-3 mt-2 max-w-[62ch]">
        Everything sent through the website&rsquo;s forms. Each one is also emailed, but this is the
        record — so nothing gets lost in an inbox.
      </p>

      {/* status filter */}
      <div className="flex flex-wrap gap-1 mt-8 border-b border-[--line]">
        {[
          ["open", `Open (${countOf("new") + countOf("contacted")})`],
          ["new", `New (${countOf("new")})`],
          ["contacted", "Contacted"],
          ["confirmed", "Confirmed"],
          ["closed", "Closed"],
          ["all", "All"],
        ].map(([key, labelText]) => (
          <Link key={key} href={q({ status: key })}
            className={`px-4 py-2.5 text-sm border-b-2 -mb-px ${
              status === key ? "border-gold font-semibold" : "border-transparent text-ink-3 hover:text-ink"}`}>
            {labelText}
          </Link>
        ))}
      </div>

      {/* type filter */}
      <div className="flex flex-wrap gap-2 mt-5">
        <Link href={q({ type: undefined })}
          className={`text-xs px-3 py-1.5 border ${!type ? "border-gold text-gold-ink" : "border-[--line] text-ink-3 hover:text-ink"}`}>
          All types
        </Link>
        {(Object.keys(TYPE_LABEL) as EnquiryType[]).map((t) => (
          <Link key={t} href={q({ type: t })}
            className={`text-xs px-3 py-1.5 border ${type === t ? "border-gold text-gold-ink" : "border-[--line] text-ink-3 hover:text-ink"}`}>
            {TYPE_LABEL[t]}
          </Link>
        ))}
      </div>

      <div className="mt-8 grid gap-4">
        {rows.map((e) => (
          <article key={e.id} className={`border border-[--line] ${e.status === "new" ? "bg-white" : "bg-white/50"}`}>
            <details open={e.status === "new"}>
              <summary className="px-5 py-4 cursor-pointer flex flex-wrap items-center gap-4 hover:bg-white">
                <span className={`inline-block px-2 py-1 text-xs font-semibold shrink-0 ${STATUS_COLOUR[e.status]}`}>
                  {e.status}
                </span>
                <span className="flex-1 min-w-48">
                  <span className="block font-medium">
                    {e.name}
                    <span className="text-ink-3 font-normal"> · {TYPE_LABEL[e.type as EnquiryType]}</span>
                  </span>
                  <span className="block text-xs text-ink-3 mt-0.5">
                    {e.branchId ? cityOf.get(e.branchId) : "No branch"} ·{" "}
                    {new Date((e.createdAt ?? 0) * 1000).toLocaleString("en-GB")}
                    {e.handledByUserId && ` · ${staffName.get(e.handledByUserId) ?? ""}`}
                  </span>
                </span>
                {e.marketingConsent && (
                  <span className="accent text-[0.55rem] text-leaf shrink-0">Marketing opt-in</span>
                )}
              </summary>

              <div className="px-5 pb-5 pt-1 bg-white">
                <dl className="grid gap-x-8 gap-y-3 sm:grid-cols-2 text-sm">
                  {[
                    ["Email", e.email ? <a key="e" href={`mailto:${e.email}`} className="underline hover:text-gold-ink">{e.email}</a> : "—"],
                    ["Phone", e.phone ? <a key="p" href={`tel:${e.phone}`} className="underline hover:text-gold-ink tnum">{e.phone}</a> : "—"],
                    ...(e.company ? [["Company", e.company]] : []),
                    ...(e.partySize ? [["Guests", String(e.partySize)]] : []),
                    ...(e.requestedDate ? [["Preferred date", `${e.requestedDate}${e.requestedTime ? ` at ${e.requestedTime}` : ""}`]] : []),
                    ...(e.occasion ? [["Occasion", e.occasion]] : []),
                    ...(e.roomId ? [["Room", roomName.get(e.roomId) ?? "—"]] : []),
                    ...(e.dietary ? [["Dietary", e.dietary]] : []),
                  ].map(([k, v], i) => (
                    <div key={i}>
                      <dt className="text-xs font-semibold text-ink-3">{k as string}</dt>
                      <dd className="mt-0.5">{v as React.ReactNode}</dd>
                    </div>
                  ))}
                </dl>

                {e.message && (
                  <div className="mt-5 border-l-2 border-[--line] pl-4">
                    <span className="text-xs font-semibold text-ink-3">Their message</span>
                    <p className="mt-1 text-sm whitespace-pre-wrap">{e.message}</p>
                  </div>
                )}

                {editable && (
                  <>
                    <form action={setEnquiryStatus} className="mt-6 pt-5 border-t border-[--line] flex flex-wrap gap-2">
                      <input type="hidden" name="id" value={e.id} />
                      {(["new", "contacted", "confirmed", "closed"] as const)
                        .filter((s) => s !== e.status)
                        .map((s) => (
                          <button key={s} name="status" value={s}
                            className="text-xs border border-[--line] px-3 py-1.5 hover:bg-pale capitalize">
                            Mark {s}
                          </button>
                        ))}
                    </form>

                    <form action={saveEnquiryNote} className="mt-4 flex flex-wrap items-end gap-3">
                      <input type="hidden" name="id" value={e.id} />
                      <div className="flex-1 min-w-[16rem]">
                        <label className="block text-xs font-semibold text-ink-3 mb-1" htmlFor={`note${e.id}`}>
                          Internal note (never shown to the customer)
                        </label>
                        <input id={`note${e.id}`} name="internalNote" defaultValue={e.internalNote ?? ""}
                          className={field} />
                      </div>
                      <button className="text-xs border border-[--line] px-3 py-2 hover:bg-pale">Save note</button>
                    </form>
                  </>
                )}
              </div>
            </details>
          </article>
        ))}

        {rows.length === 0 && (
          <p className="border border-[--line] bg-white/50 px-5 py-10 text-center text-ink-3">
            Nothing here. {status === "open" ? "No open enquiries — all caught up." : "Try another filter."}
          </p>
        )}
      </div>
    </>
  );
}
