import { submitEnquiryAction } from "@/app/(site)/[branch]/enquiry-actions";

export type EnquiryField =
  | "phone" | "company" | "location" | "partySize" | "date" | "time" | "occasion" | "room" | "dietary";

/**
 * The one enquiry form, configured per page.
 *
 * The old site had five near-identical YOOessentials forms, each emailing a
 * slightly different address with a slightly different field list and no
 * record kept anywhere. This is the same set of fields, driven by props, all
 * writing to one table — so nothing can be lost and every page's form behaves
 * identically.
 */
export function EnquiryForm({
  type, branchSlug, fields = [], rooms = [], occasions = [], heading, intro, submitLabel = "Send enquiry",
  privacyHref, messageLabel = "Your message", messagePlaceholder,
}: {
  type: "booking" | "private_room" | "corporate" | "catering" | "contact" | "franchise";
  branchSlug: string | null;
  fields?: EnquiryField[];
  rooms?: { id: number; name: string }[];
  occasions?: string[];
  heading?: string;
  intro?: string;
  submitLabel?: string;
  privacyHref: string;
  messageLabel?: string;
  messagePlaceholder?: string;
}) {
  const has = (f: EnquiryField) => fields.includes(f);
  const field =
    "w-full border border-[--line] px-3.5 py-3 text-[0.95rem] outline-none focus:border-gold rounded-none";
  const label = "block accent text-[0.6rem] text-gold mb-2";

  return (
    <form action={submitEnquiryAction} className="grid gap-6">
      <input type="hidden" name="type" value={type} />
      <input type="hidden" name="branch" value={branchSlug ?? ""} />

      {heading && <h2 className="text-2xl sm:text-3xl">{heading}</h2>}
      {intro && <p className="text-pale/55 max-w-[62ch] -mt-2">{intro}</p>}

      <div className="grid gap-6 sm:grid-cols-2">
        <div>
          <label className={label} htmlFor={`${type}-name`}>Your name</label>
          <input id={`${type}-name`} name="name" required autoComplete="name" className={field} />
        </div>
        <div>
          <label className={label} htmlFor={`${type}-email`}>Email</label>
          <input id={`${type}-email`} name="email" type="email" required autoComplete="email" className={field} />
        </div>

        {has("phone") && (
          <div>
            <label className={label} htmlFor={`${type}-phone`}>Phone</label>
            <input id={`${type}-phone`} name="phone" type="tel" autoComplete="tel" className={field} />
          </div>
        )}
        {has("company") && (
          <div>
            <label className={label} htmlFor={`${type}-company`}>Company</label>
            <input id={`${type}-company`} name="company" className={field} />
          </div>
        )}
        {has("location") && (
          <div>
            <label className={label} htmlFor={`${type}-location`}>Franchise location</label>
            <input id={`${type}-location`} name="location" placeholder="City or territory" className={field} />
          </div>
        )}
        {has("partySize") && (
          <div>
            <label className={label} htmlFor={`${type}-party`}>Number of guests</label>
            <input id={`${type}-party`} name="partySize" type="number" min={1} className={field} />
          </div>
        )}
        {has("date") && (
          <div>
            <label className={label} htmlFor={`${type}-date`}>Preferred date</label>
            <input id={`${type}-date`} name="requestedDate" type="date" className={field} />
          </div>
        )}
        {has("time") && (
          <div>
            <label className={label} htmlFor={`${type}-time`}>Preferred time</label>
            <input id={`${type}-time`} name="requestedTime" type="time" className={field} />
          </div>
        )}
        {has("occasion") && occasions.length > 0 && (
          <div>
            <label className={label} htmlFor={`${type}-occasion`}>Occasion</label>
            <select id={`${type}-occasion`} name="occasion" defaultValue={occasions[0]} className={field}>
              {occasions.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
        )}
        {has("room") && rooms.length > 0 && (
          <div>
            <label className={label} htmlFor={`${type}-room`}>Which room?</label>
            <select id={`${type}-room`} name="roomId" defaultValue="" className={field}>
              <option value="">Not sure — please advise</option>
              {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
          </div>
        )}
        {has("dietary") && (
          <div className="sm:col-span-2">
            <label className={label} htmlFor={`${type}-dietary`}>Dietary requirements</label>
            <input id={`${type}-dietary`} name="dietary" placeholder="Allergies, vegetarian, vegan…" className={field} />
          </div>
        )}

        <div className="sm:col-span-2">
          <label className={label} htmlFor={`${type}-message`}>{messageLabel}</label>
          <textarea id={`${type}-message`} name="message" rows={5} maxLength={4000}
            placeholder={messagePlaceholder} className={field} />
        </div>
      </div>

      <div className="grid gap-3">
        <label className="flex gap-3 text-sm items-start">
          <input type="checkbox" name="terms" required className="mt-1" />
          <span>
            I&rsquo;m happy for Varanasi to hold these details in order to reply to me, as set out in the{" "}
            <a href={privacyHref} className="underline hover:text-gold">privacy policy</a>.
          </span>
        </label>
        <label className="flex gap-3 text-sm items-start">
          <input type="checkbox" name="marketing" className="mt-1" />
          <span>I&rsquo;d also like to hear about events, new menus and offers.</span>
        </label>
      </div>

      <button className="btn btn-gold justify-self-start">{submitLabel}</button>
    </form>
  );
}
