export function Footer() {
  return (
    <footer className="bg-ink border-t border-white/10">
      <div className="mx-auto max-w-[84rem] px-5 lg:px-10 py-8">
        <p className="text-xs text-pale/40">© 2026 Varanasi Restaurant</p>
      </div>
    </footer>
  );
}
