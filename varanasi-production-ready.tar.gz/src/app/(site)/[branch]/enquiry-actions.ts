"use server";
import { redirect } from "next/navigation";
import { submitEnquiry, type EnquiryType } from "@/lib/enquiry";

/**
 * One action behind every enquiry form on the site. Which page it came from is
 * carried in `type`, so the record says what the person was actually asking
 * about — a franchise enquiry and a table enquiry shouldn't land in one
 * undifferentiated pile, which is what the old email-only setup produced.
 */
export async function submitEnquiryAction(formData: FormData) {
  const type = String(formData.get("type") ?? "contact") as EnquiryType;
  const branchSlug = String(formData.get("branch") ?? "") || null;
  const page = String(formData.get("returnTo") ?? "") ||
    (branchSlug ? `/${branchSlug}/contact` : "/");

  const partyRaw = String(formData.get("partySize") ?? "");
  const roomRaw = String(formData.get("roomId") ?? "");

  const result = await submitEnquiry({
    type,
    branchSlug,
    name: String(formData.get("name") ?? ""),
    email: String(formData.get("email") ?? ""),
    phone: String(formData.get("phone") ?? "") || null,
    company: String(formData.get("company") ?? "") || null,
    location: String(formData.get("location") ?? "") || null,
    message: String(formData.get("message") ?? "") || null,
    partySize: partyRaw ? Number(partyRaw) : null,
    requestedDate: String(formData.get("requestedDate") ?? "") || null,
    requestedTime: String(formData.get("requestedTime") ?? "") || null,
    occasion: String(formData.get("occasion") ?? "") || null,
    roomId: roomRaw ? Number(roomRaw) : null,
    dietary: String(formData.get("dietary") ?? "") || null,
    marketingConsent: formData.get("marketing") === "on",
    termsAccepted: formData.get("terms") === "on",
  });

  if (!result.ok) redirect(`${page}?error=${encodeURIComponent(result.error)}`);
  redirect(`${page}?sent=1`);
}
