import Link from "next/link";
import "../globals.css";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { stripeConfigured } from "@/lib/stripe";
import { formatPence } from "@/lib/money";

export const metadata: Metadata = { title: "Checkout", robots: { index: false } };
export const dynamic = "force-dynamic";

/**
 * Stands in for Stripe's hosted payment page until real keys are in place.
 *
 * This exists so the reservation journey — including the failure path the
 * client specifically asked about — can be walked end to end today, without
 * waiting on a Stripe account. The moment `STRIPE_SECRET_KEY` is set this route
 * returns 404 and the real Stripe Checkout takes over; nothing else changes.
 *
 * It never asks for card details, because it isn't a payment page. It's two
 * buttons that stand for "the payment worked" and "it didn't".
 */
export default async function CheckoutSimulator({
  searchParams,
}: {
  searchParams: Promise<{ ref?: string; amount?: string; success?: string; cancel?: string }>;
}) {
  // With real Stripe configured, this must not be reachable.
  if (stripeConfigured()) notFound();

  const { ref, amount, success, cancel } = await searchParams;
  if (!ref || !success || !cancel) notFound();

  // Only ever bounce back into this site.
  const safe = (url: string) => (url.startsWith("/") || url.includes("://") ? url : "/");
  const bookingAmount = Number(amount ?? 0);
  const getRoot = () => {
    const url = new URL(cancel || "/");
    return `/${url.pathname.split("/")[1]}`;
  };

  return (
    <main className="min-h-dvh bg-ink text-pale py-8 px-5">
      <div className="mx-auto max-w-[48rem]">
        {/* Header with back button */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <p className="accent text-[0.6rem] text-gold">Secure Checkout</p>
            <h1 className="text-2xl sm:text-3xl mt-2">Complete your booking</h1>
          </div>
          <Link href={getRoot()} className="btn btn-outline text-sm whitespace-nowrap">
            ← Back to home
          </Link>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main checkout card */}
          <div className="lg:col-span-2">
            <div className="bg-white text-ink rounded border border-white/10">
              {/* Order summary */}
              <div className="px-6 py-6 border-b border-[--line]">
                <h2 className="font-semibold text-lg">Order summary</h2>

                <div className="mt-6 space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-[--line]">
                    <span className="text-sm text-ink-3">Booking reference</span>
                    <span className="font-mono text-sm font-semibold">{ref}</span>
                  </div>
                  <div className="flex justify-between items-baseline py-3">
                    <span className="text-sm text-ink-3">Deposit required</span>
                    <span className="text-2xl tnum display text-gold">{formatPence(bookingAmount)}</span>
                  </div>
                </div>

                <p className="mt-6 text-xs text-ink-3 leading-relaxed border-l-2 border-gold bg-gold/10 px-3 py-2.5">
                  ℹ️ This is a simulator. Stripe isn't connected yet. Choose an outcome below to test what
                  guests experience. With Stripe keys in place, guests land on Stripe's secure page instead.
                </p>
              </div>

              {/* Payment options */}
              <div className="px-6 py-6">
                <h3 className="font-semibold mb-4">Test payment outcome</h3>

                <div className="grid gap-3">
                  <button
                    onClick={() => {
                      window.location.href = safe(success);
                    }}
                    className="btn btn-gold text-center"
                  >
                    ✓ Simulate successful payment
                  </button>
                  <button
                    onClick={() => {
                      window.location.href = safe(cancel);
                    }}
                    className="btn text-center border border-brick/40 text-brick hover:bg-clay/10"
                  >
                    ✕ Simulate payment failed
                  </button>
                </div>

                <p className="mt-4 text-xs text-ink-3 leading-relaxed">
                  Success: Table is confirmed and confirmation emails are sent.<br />
                  Failure: Table is released and guest is informed.
                </p>
              </div>
            </div>

            {/* Additional actions */}
            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <a href={safe(cancel)} className="btn btn-outline flex-1 text-center text-sm">
                Cancel booking
              </a>
              <Link href={getRoot()} className="btn btn-ink flex-1 text-center text-sm">
                Continue shopping
              </Link>
            </div>
          </div>

          {/* Order summary sidebar (desktop) */}
          <div className="hidden lg:block">
            <div className="sticky top-6 bg-ink-2 p-6 border border-white/10">
              <h3 className="font-semibold text-pale mb-4">Booking details</h3>

              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-pale/50 text-xs uppercase">Reference</p>
                  <p className="font-mono text-pale mt-1">{ref}</p>
                </div>

                <div className="border-t border-white/10 pt-3">
                  <p className="text-pale/50 text-xs uppercase">Total due</p>
                  <p className="text-2xl tnum display text-gold mt-1">{formatPence(bookingAmount)}</p>
                </div>

                <div className="border-t border-white/10 pt-3 text-pale/70 text-xs leading-relaxed">
                  <p>This deposit secures your table. The remaining balance is due on arrival.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Help text */}
        <div className="mt-12 p-4 bg-gold/10 border border-gold/30 text-xs text-pale/70 leading-relaxed">
          <p className="font-semibold text-pale mb-2">💬 About this payment</p>
          <p>
            We use Stripe for secure payments. Your card details are never shared with us. Once Stripe is configured,
            you'll be redirected to their secure payment page. This simulator shows the complete booking flow.
          </p>
        </div>
      </div>
    </main>
  );
}
